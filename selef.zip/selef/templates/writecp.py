import RPi.GPIO as GPIO
import SimpleMFRC522

reader = SimpleMFRC522.SimpleMFRC522()

try:
	text= raw_input('Ingrese nuevo ddato para la tarjeta')
	print('Ubique la tarjeta en el lector')
	reader.write(text)
	print('Datos escritos Exitosamente')
finally:
	GPIO.cleanup()
