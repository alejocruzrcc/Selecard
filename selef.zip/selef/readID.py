import RPi.GPIO as GPIO
import SimpleMFRC522
import pyrebase
from requests import get
from flask import Flask, render_template
from flask import request
from flask_restful import Resource, Api
import json

app= Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def home():    
	if request.method == 'POST':
		def leerCard():
	
			reader = SimpleMFRC522.SimpleMFRC522()

			print ('Buscando Tarejtas...')
			print('Presiona Ctrl-C para detener')

			try: 
				ID, text = reader.read()
				textnuevo= text.split()
							
			finally:
					GPIO.cleanup()
			return textnuevo

		def comparar(llave):
			email= llave[0]
			password= llave[1]
			
			config = {
			"apiKey": "AIzaSyA8z1ZSK50myGH-jyN2BRMhkEleHzo3AwE",
			"authDomain": "testpy-69f51.firebaseapp.com",
			"databaseURL": "https://testpy-69f51.firebaseio.com",
			"projectId": "testpy-69f51",
			"storageBucket": "testpy-69f51.appspot.com",
			"messagingSenderId": "755521623259"	}

			firebase= pyrebase.initialize_app(config)
			auth = firebase.auth()
						
			try:
				user= auth.sign_in_with_email_and_password(email,password)
				print(auth.get_account_info(user['idToken']))
				return 'Ingreso exitoso'
			except:
				return 'Usuario no registrado'
		
			return user
		textN= leerCard()
		registro= comparar(textN) 
		return registro
		successful= "Login Successful"
		unsuccessful= "Error al ingresar"
	return render_template('home.html')
    
@app.route('/signup', methods=['GET', 'POST']) 
def signup():
	if request.method =="POST":
		emailR = request.form['emailR']
		passwordR= request.form['passR']
		successful= "Registrado con exito"
		unsuccessful= "Error al registrar"
		def registrar(email, password):

			config = {
			"apiKey": "AIzaSyA8z1ZSK50myGH-jyN2BRMhkEleHzo3AwE",
			"authDomain": "testpy-69f51.firebaseapp.com",
			"databaseURL": "https://testpy-69f51.firebaseio.com",
			"projectId": "testpy-69f51",
			"storageBucket": "testpy-69f51.appspot.com",
			"messagingSenderId": "755521623259"	}

			firebase= pyrebase.initialize_app(config)
			auth = firebase.auth()			
			try: 				
				user= auth.create_user_with_email_and_password(email,password)
				infoC= auth.get_account_info(user['idToken'])
				infoU= infoC['users']
				datos= infoU[0]
				uid= datos.get('localId')				
				textcp= emailR+" "+passwordR
								
				def generateKey(ui):
					reader = SimpleMFRC522.SimpleMFRC522()
					try:
						text= ui
						print('Ubique la tarjeta en el lector')
						reader.write(text)
						print('Datos escritos Exitosamente')
					finally:
						GPIO.cleanup()
				generateKey(textcp)
			except:				
				return 'Error'
			return user
		
		registro= registrar(emailR, passwordR)
		if(registro):
			return render_template('signup.html', ss= successful)
		else:
			return render_template('signup.html', us= unsuccessful)
	return render_template('signup.html')

if __name__ == '__main__':
    app.run(debug = True, port=3000)
