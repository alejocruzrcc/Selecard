import RPi.GPIO as GPIO
import SimpleMFRC522

def leerCard():
	reader = SimpleMFRC522.SimpleMFRC522()

	#Welcome Message
	print ('Buscando Tarejtas...')
	print('Presiona Ctrl-C para detener')

	try: 
		ID, text = reader.read()
		print(ID)
		print (text)
	finally:
		GPIO.cleanup()
	return text
leerCard()
